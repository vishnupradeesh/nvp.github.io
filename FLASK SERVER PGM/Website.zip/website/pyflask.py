from flask import Flask,render_template
app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html",title = "Main")
@app.route("/home.html")
def home():
    return render_template("home.html",title = "Home")
@app.route("/Contact.html")
def Contact():
    return render_template("Contact.html",title = "Contact")
@app.route("/About.html")
def About():
    return render_template("About.html",title = "About")
@app.route("/Signup.html")
def SignUp():
    return render_template("Signup.html")
app.run()